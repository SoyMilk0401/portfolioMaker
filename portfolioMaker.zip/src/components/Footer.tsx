export default function Footer() {
    return (
        <div className="Footer">
            Footer
        </div>
    )
}